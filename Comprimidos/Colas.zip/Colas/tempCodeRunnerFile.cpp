
    generador->generarCliente(*cola);